/******************************************************************************
 *
 * 
 *
 * Copyright (C) 1997-2001 by Dimitri van Heesch.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation under the terms of the GNU General Public License is hereby 
 * granted. No representations are made about the suitability of this software 
 * for any purpose. It is provided "as is" without express or implied warranty.
 * See the GNU General Public License for more details.
 *
 * Documents produced by Doxygen are derivative works derived from the
 * input used in their production; they are not affected by this license.
 *
 */

#ifndef OPTIMC_H
#define OPTIMC_H

//----------------------------------------------------------------------------
// Methods that replace the usage of the older implementations.  The old methods
// decided the functionality based on the result of 
// Config_getBool("OPTIMIZE_OUTPUT_FOR_C") inside TranslatorXxxx.
// This was the serious obstacle for automatic conversion of the translators
// to the entity based solution (see document "Translators Revisited").
// So for example, instead of calling theTranslator->trCompoundList(),
// do call only trCompoundList() in the doxygen core code.

QCString trCompoundList();
QCString trMemberDataDocumentation();
QCString trCompoundMembers();
QCString trClasses();
QCString trFileMembers();
QCString trPublicAttribs();
QCString trCompounds();
QCString trClassDocumentation();
QCString trCompoundIndex();
QCString trFileMembersDescription(bool extractAll);
QCString trCompoundMembersDescription(bool extractAll);
QCString trCompoundListDescription();

#endif
