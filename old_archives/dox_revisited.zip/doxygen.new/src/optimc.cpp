/******************************************************************************
 *
 * 
 *
 * Copyright (C) 1997-2001 by Dimitri van Heesch.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation under the terms of the GNU General Public License is hereby 
 * granted. No representations are made about the suitability of this software 
 * for any purpose. It is provided "as is" without express or implied warranty.
 * See the GNU General Public License for more details.
 *
 * Documents produced by Doxygen are derivative works derived from the
 * input used in their production; they are not affected by this license.
 *
 */

#include "language.h"
#include "optimc.h"

//----------------------------------------------------------------------------
// Methods that replace the usage of the older implementations.  The old methods
// decided the functionality based on the result of 
// Config_getBool("OPTIMIZE_OUTPUT_FOR_C") inside TranslatorXxxx.
// This was the serious obstacle for automatic conversion of the translators
// to the entity based solution (see document "Translators Revisited").
// So for example, instead of calling theTranslator->trCompoundList(),
// do call only trCompoundList() in the doxygen core code.

QCString trCompoundList()
{
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataStructures()
           : theTranslator->trCompoundListCpp();
}


QCString trMemberDataDocumentation()
{
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trFieldDocumentation()
           : theTranslator->trMemberDataDocumentationCpp();
}


QCString trCompoundMembers()
{
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataFields()
           : theTranslator->trCompoundMembersCpp();
}


QCString trClasses()
{
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataStructures()
           : theTranslator->trClass(true, true);
}


QCString trFileMembers()
{
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trGlobals()
           : theTranslator->trFileMembersCpp();
}


QCString trPublicAttribs()
{
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataFields()
           : theTranslator->trPublicAttribsCpp();
}


QCString trCompounds()
{ 
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataStructures()
           : theTranslator->trCompoundsCpp();
}


QCString trClassDocumentation()
{ 
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataStructureDocumentation()
           : theTranslator->trClassDocumentationCpp();
}


QCString trCompoundIndex()
{ 
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trDataStructureIndex()
           : theTranslator->trCompoundIndexCpp();
}


QCString trFileMembersDescription(bool extractAll)
{ 
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trFileMembersDescriptionC(extractAll)
           : theTranslator->trFileMembersDescriptionCpp(extractAll);
}


QCString trCompoundMembersDescription(bool extractAll)
{ 
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trCompoundMembersDescriptionC(extractAll)
           : theTranslator->trCompoundMembersDescriptionCpp(extractAll);
}


QCString trCompoundListDescription()
{ 
  return Config_getBool("OPTIMIZE_OUTPUT_FOR_C")
           ? theTranslator->trCompoundListDescriptionC()
           : theTranslator->trCompoundListDescriptionCpp();
}
