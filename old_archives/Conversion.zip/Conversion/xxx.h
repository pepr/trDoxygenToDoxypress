#ifndef XXX_H
#define XXX_H

#include <string>

typedef std::string QCString;
typedef std::string QString;

typedef unsigned short Q_UINT16;

std::string generateMarker(int id);
bool Config_getBool(const std::string & s);
void Config_setBool(bool bValue);

struct ClassDef
{
    /*! The various compound types */
    enum CompoundType 
    { 
        Class,
        Struct,
        Union,
        Interface,
        Exception,
    };
};


#endif // XXX_H