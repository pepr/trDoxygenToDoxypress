/*! \file main.cpp \brief Simply the main() */

#include <iostream>
#include <fstream>
#include <string>

#include "language.h"

void GenerateTranslatorEntities(const std::string & sLang);

int main()
{
    GenerateTranslatorEntities("czech");
    GenerateTranslatorEntities("dutch");
    GenerateTranslatorEntities("english");

    return 0;
}


void WriteHeading(std::ofstream & fout,
                  const std::string & CountryName,
                  const std::string & CharsetId)
{
    fout << "<?xml encoding=\"" << CharsetId << "\"?>\n"
            "<!-- " << CountryName << " -->\n\n";
}


void WriteEntity(std::ofstream & fout, 
                 const std::string & EntityId,
                 const std::string & EntityBody)
{   
    // Entity definitions start always with the ENTITY and 
    // the entity identifier.
    //
    fout << "<!ENTITY " << EntityId << " ";
    
    // Multiline entities will use CDATA syntactic construction,
    // one-line definitions will use quotation marks.
    //
    bool IsMultiline = (EntityBody.find("\n") != std::string::npos);
    
    fout << ((IsMultiline) ? "<![CDATA[" : "\"");
    
    // Now output the body.
    //
    fout << EntityBody;
    
    // Close the definition.
    //
    fout << ((IsMultiline) ? "]]>" : "\"") << " >\n";      
}

void GenerateTranslatorEntities(const std::string & sLang)
{
    std::cerr << "Generating entity definitions for " << sLang << " ... ";
    
    // Construct the File Name.
    //
    std::string sFilename(sLang + "Lang.ent");

    // Open the file for writing.
    //
    std::ofstream fout;
    fout.open(sFilename.c_str());

    // If the file could not be open, finish with error message.
    //
    if (! fout.is_open())
    {
        std::cerr << "Open for output to " << sFilename
                  << " failed.\n";
        exit(1);
    }

    // File was open for writing. Generate the output.
    //
    // If the translator object exists, delete it. New one will
    // be created immediately.
    //
    if (theTranslator != 0)
        delete theTranslator;

    // Set the language.
    //
    setTranslator(sLang.c_str());
    
    // Generate entity definitions for all translator methods.
    //
    WriteHeading(fout, theTranslator->idLanguage(), 
                       theTranslator->idLanguageCharset());
    
    fout << "<!-- Simple entities -->\n\n";

    WriteEntity(fout, "trAlphabeticalList",
        theTranslator->trAlphabeticalList());
    
    WriteEntity(fout, "idLanguage",
        theTranslator->idLanguage());
    
    WriteEntity(fout, "latexLanguageSupportCommand",
        theTranslator->latexLanguageSupportCommand());
    
    WriteEntity(fout, "idLanguageCharset",
        theTranslator->idLanguageCharset());
    
    WriteEntity(fout, "trRelatedFunctions",
        theTranslator->trRelatedFunctions());
    
    WriteEntity(fout, "trRelatedSubscript",
        theTranslator->trRelatedSubscript());
    
    WriteEntity(fout, "trDetailedDescription",
        theTranslator->trDetailedDescription());
    
    WriteEntity(fout, "trMemberTypedefDocumentation",
        theTranslator->trMemberTypedefDocumentation());
    
    WriteEntity(fout, "trMemberEnumerationDocumentation",
        theTranslator->trMemberEnumerationDocumentation());
    
    WriteEntity(fout, "trMemberFunctionDocumentation",
        theTranslator->trMemberFunctionDocumentation());
    
    Config_setBool(true);
    WriteEntity(fout, "trMemberDataDocumentationC",
        theTranslator->trMemberDataDocumentation());

    Config_setBool(false);
    WriteEntity(fout, "trMemberDataDocumentation",
        theTranslator->trMemberDataDocumentation());
    

    WriteEntity(fout, "trMore",
        theTranslator->trMore());
    
    WriteEntity(fout, "trListOfAllMembers",
        theTranslator->trListOfAllMembers());
    
    WriteEntity(fout, "trMemberList",
        theTranslator->trMemberList());
    
    
    WriteEntity(fout, "trEnumName",
        theTranslator->trEnumName());
    
    WriteEntity(fout, "trEnumValue",
        theTranslator->trEnumValue());
    
    WriteEntity(fout, "trDefinedIn",
        theTranslator->trDefinedIn());
    
    WriteEntity(fout, "trModules",
        theTranslator->trModules());
    
    WriteEntity(fout, "trClassHierarchy",
        theTranslator->trClassHierarchy());
    
    Config_setBool(true);
    WriteEntity(fout, "trCompoundListC",
        theTranslator->trCompoundList());
    
    Config_setBool(false);
    WriteEntity(fout, "trCompoundList",
        theTranslator->trCompoundList());
    
    WriteEntity(fout, "trFileList",
        theTranslator->trFileList());
    
    Config_setBool(true);
    WriteEntity(fout, "trHeaderFilesC",
        theTranslator->trHeaderFiles());
    
    Config_setBool(false);
    WriteEntity(fout, "trHeaderFiles",
        theTranslator->trHeaderFiles());
    
    WriteEntity(fout, "trCompoundMembers",
        theTranslator->trCompoundMembers());
    
    Config_setBool(true);
    WriteEntity(fout, "trFileMembersC",
        theTranslator->trFileMembers());
    
    Config_setBool(false);
    WriteEntity(fout, "trFileMembers",
        theTranslator->trFileMembers());
    
    WriteEntity(fout, "trRelatedPages",
        theTranslator->trRelatedPages());
    
    WriteEntity(fout, "trExamples",
        theTranslator->trExamples());
    
    WriteEntity(fout, "trSearch",
        theTranslator->trSearch());
    
    WriteEntity(fout, "trClassHierarchyDescription",
        theTranslator->trClassHierarchyDescription());
    
    Config_setBool(true);
    WriteEntity(fout, "trCompoundListDescriptionC",
        theTranslator->trCompoundListDescription());
    
    Config_setBool(false);
    WriteEntity(fout, "trCompoundListDescription",
        theTranslator->trCompoundListDescription());
    
    WriteEntity(fout, "trHeaderFilesDescription",
        theTranslator->trHeaderFilesDescription());
    
    WriteEntity(fout, "trExamplesDescription",
        theTranslator->trExamplesDescription());
    
    WriteEntity(fout, "trRelatedPagesDescription",
        theTranslator->trRelatedPagesDescription());
    
    WriteEntity(fout, "trModulesDescription",
        theTranslator->trModulesDescription());
    
    WriteEntity(fout, "trNoDescriptionAvailable",
        theTranslator->trNoDescriptionAvailable());
    
    WriteEntity(fout, "trDocumentation",
        theTranslator->trDocumentation());
    
    WriteEntity(fout, "trModuleIndex",
        theTranslator->trModuleIndex());
    
    WriteEntity(fout, "trHierarchicalIndex",
        theTranslator->trHierarchicalIndex());
    
    Config_setBool(true);
    WriteEntity(fout, "trCompoundIndexC",
        theTranslator->trCompoundIndex());
    
    Config_setBool(false);
    WriteEntity(fout, "trCompoundIndex",
        theTranslator->trCompoundIndex());
    
    WriteEntity(fout, "trFileIndex",
        theTranslator->trFileIndex());
    
    WriteEntity(fout, "trModuleDocumentation",
        theTranslator->trModuleDocumentation());
    
    Config_setBool(true);
    WriteEntity(fout, "trClassDocumentationC",
        theTranslator->trClassDocumentation());
    
    Config_setBool(false);
    WriteEntity(fout, "trClassDocumentation",
        theTranslator->trClassDocumentation());
    
    WriteEntity(fout, "trFileDocumentation",
        theTranslator->trFileDocumentation());
    
    WriteEntity(fout, "trExampleDocumentation",
        theTranslator->trExampleDocumentation());
    
    WriteEntity(fout, "trPageDocumentation",
        theTranslator->trPageDocumentation());
    
    WriteEntity(fout, "trReferenceManual",
        theTranslator->trReferenceManual());
    
    WriteEntity(fout, "trDefines",
        theTranslator->trDefines());
    
    WriteEntity(fout, "trFuncProtos",
        theTranslator->trFuncProtos());
    
    WriteEntity(fout, "trTypedefs",
        theTranslator->trTypedefs());
    
    WriteEntity(fout, "trEnumerations",
        theTranslator->trEnumerations());
    
    WriteEntity(fout, "trFunctions",
        theTranslator->trFunctions());
    
    WriteEntity(fout, "trVariables",
        theTranslator->trVariables());
    
    WriteEntity(fout, "trEnumerationValues",
        theTranslator->trEnumerationValues());
    
    WriteEntity(fout, "trDefineDocumentation",
        theTranslator->trDefineDocumentation());
    
    WriteEntity(fout, "trFunctionPrototypeDocumentation",
        theTranslator->trFunctionPrototypeDocumentation());
    
    WriteEntity(fout, "trTypedefDocumentation",
        theTranslator->trTypedefDocumentation());
    
    WriteEntity(fout, "trEnumerationTypeDocumentation",
        theTranslator->trEnumerationTypeDocumentation());
    
    WriteEntity(fout, "trEnumerationValueDocumentation",
        theTranslator->trEnumerationValueDocumentation());
    
    WriteEntity(fout, "trFunctionDocumentation",
        theTranslator->trFunctionDocumentation());
    
    WriteEntity(fout, "trVariableDocumentation",
        theTranslator->trVariableDocumentation());
    
    Config_setBool(true);
    WriteEntity(fout, "trCompoundsC",
        theTranslator->trCompounds());
    
    Config_setBool(false);
    WriteEntity(fout, "trCompounds",
        theTranslator->trCompounds());
    
    WriteEntity(fout, "trWrittenBy",
        theTranslator->trWrittenBy());
    
    WriteEntity(fout, "trForInternalUseOnly",
        theTranslator->trForInternalUseOnly());
    
    WriteEntity(fout, "trReimplementedForInternalReasons",
        theTranslator->trReimplementedForInternalReasons());
    
    WriteEntity(fout, "trWarning",
        theTranslator->trWarning());
    
    WriteEntity(fout, "trBugsAndLimitations",
        theTranslator->trBugsAndLimitations());
    
    WriteEntity(fout, "trVersion",
        theTranslator->trVersion());
    
    WriteEntity(fout, "trDate",
        theTranslator->trDate());
    
    WriteEntity(fout, "trReturns",
        theTranslator->trReturns());
    
    WriteEntity(fout, "trSeeAlso",
        theTranslator->trSeeAlso());
    
    WriteEntity(fout, "trParameters",
        theTranslator->trParameters());
    
    WriteEntity(fout, "trExceptions",
        theTranslator->trExceptions());
    
    WriteEntity(fout, "trGeneratedBy",
        theTranslator->trGeneratedBy());
    
    WriteEntity(fout, "trNamespaceList",
        theTranslator->trNamespaceList());
    
    WriteEntity(fout, "trFriends",
        theTranslator->trFriends());
    
    WriteEntity(fout, "trRelatedFunctionDocumentation",
        theTranslator->trRelatedFunctionDocumentation());
    
    WriteEntity(fout, "trPublicMembers",
        theTranslator->trPublicMembers());
    
    WriteEntity(fout, "trPublicSlots",
        theTranslator->trPublicSlots());
    
    WriteEntity(fout, "trSignals",
        theTranslator->trSignals());
    
    WriteEntity(fout, "trStaticPublicMembers",
        theTranslator->trStaticPublicMembers());
    
    WriteEntity(fout, "trProtectedMembers",
        theTranslator->trProtectedMembers());
    
    WriteEntity(fout, "trProtectedSlots",
        theTranslator->trProtectedSlots());
    
    WriteEntity(fout, "trStaticProtectedMembers",
        theTranslator->trStaticProtectedMembers());
    
    WriteEntity(fout, "trPrivateMembers",
        theTranslator->trPrivateMembers());
    
    WriteEntity(fout, "trPrivateSlots",
        theTranslator->trPrivateSlots());
    
    WriteEntity(fout, "trStaticPrivateMembers",
        theTranslator->trStaticPrivateMembers());
    
    WriteEntity(fout, "trNamespaceMembers",
        theTranslator->trNamespaceMembers());
    
    WriteEntity(fout, "trNamespaceIndex",
        theTranslator->trNamespaceIndex());
    
    WriteEntity(fout, "trNamespaceDocumentation",
        theTranslator->trNamespaceDocumentation());
    
    WriteEntity(fout, "trNamespaces",
        theTranslator->trNamespaces());
    
    WriteEntity(fout, "trAlphabeticalList",
        theTranslator->trAlphabeticalList());
    
    WriteEntity(fout, "trReturnValues",
        theTranslator->trReturnValues());
    
    WriteEntity(fout, "trMainPage",
        theTranslator->trMainPage());
    
    WriteEntity(fout, "trPageAbbreviation",
        theTranslator->trPageAbbreviation());
    
    WriteEntity(fout, "trSources",
        theTranslator->trSources());
    
    WriteEntity(fout, "trDeprecated",
        theTranslator->trDeprecated());
    
    WriteEntity(fout, "trConstructorDocumentation",
        theTranslator->trConstructorDocumentation());
    
    WriteEntity(fout, "trGotoSourceCode",
        theTranslator->trGotoSourceCode());
    
    WriteEntity(fout, "trGotoDocumentation",
        theTranslator->trGotoDocumentation());
    
    WriteEntity(fout, "trPrecondition",
        theTranslator->trPrecondition());
    
    WriteEntity(fout, "trPostcondition",
        theTranslator->trPostcondition());
    
    WriteEntity(fout, "trInvariant",
        theTranslator->trInvariant());
    
    WriteEntity(fout, "trInitialValue",
        theTranslator->trInitialValue());
    
    WriteEntity(fout, "trCode",
        theTranslator->trCode());
    
    WriteEntity(fout, "trGraphicalHierarchy",
        theTranslator->trGraphicalHierarchy());
    
    WriteEntity(fout, "trGotoGraphicalHierarchy",
        theTranslator->trGotoGraphicalHierarchy());
    
    WriteEntity(fout, "trGotoTextualHierarchy",
        theTranslator->trGotoTextualHierarchy());
    
    WriteEntity(fout, "trPageIndex",
        theTranslator->trPageIndex());
    
    WriteEntity(fout, "trNote",
        theTranslator->trNote());
    
    WriteEntity(fout, "trPublicTypes",
        theTranslator->trPublicTypes());
    
    Config_setBool(true);
    WriteEntity(fout, "trPublicAttribsC",
        theTranslator->trPublicAttribs());
    
    Config_setBool(false);
    WriteEntity(fout, "trPublicAttribs",
        theTranslator->trPublicAttribs());
    
    WriteEntity(fout, "trStaticPublicAttribs",
        theTranslator->trStaticPublicAttribs());
    
    WriteEntity(fout, "trProtectedTypes",
        theTranslator->trProtectedTypes());
    
    WriteEntity(fout, "trProtectedAttribs",
        theTranslator->trProtectedAttribs());
    
    WriteEntity(fout, "trStaticProtectedAttribs",
        theTranslator->trStaticProtectedAttribs());
    
    WriteEntity(fout, "trPrivateTypes",
        theTranslator->trPrivateTypes());
    
    WriteEntity(fout, "trPrivateAttribs",
        theTranslator->trPrivateAttribs());
    
    WriteEntity(fout, "trStaticPrivateAttribs",
        theTranslator->trStaticPrivateAttribs());
    
    WriteEntity(fout, "trTodo",
        theTranslator->trTodo());
    
    WriteEntity(fout, "trTodoList",
        theTranslator->trTodoList());
    
    WriteEntity(fout, "trReferencedBy",
        theTranslator->trReferencedBy());
    
    WriteEntity(fout, "trRemarks",
        theTranslator->trRemarks());
    
    WriteEntity(fout, "trAttention",
        theTranslator->trAttention());
    
    WriteEntity(fout, "trInclByDepGraph",
        theTranslator->trInclByDepGraph());
    
    WriteEntity(fout, "trSince",
        theTranslator->trSince());
    
    WriteEntity(fout, "trLegendTitle",
        theTranslator->trLegendTitle());
    
    WriteEntity(fout, "trLegendDocs",
        theTranslator->trLegendDocs());
    
    WriteEntity(fout, "trLegend",
        theTranslator->trLegend());
    
    WriteEntity(fout, "trTest",
        theTranslator->trTest());
    
    WriteEntity(fout, "trTestList",
        theTranslator->trTestList());
    
    WriteEntity(fout, "trDCOPMethods",
        theTranslator->trDCOPMethods());
    
    WriteEntity(fout, "trProperties",
        theTranslator->trProperties());
    
    WriteEntity(fout, "trPropertyDocumentation",
        theTranslator->trPropertyDocumentation());
    
    WriteEntity(fout, "trInterfaces",
        theTranslator->trInterfaces());
    
    Config_setBool(true);
    WriteEntity(fout, "trClassesC",
        theTranslator->trClasses());
    
    Config_setBool(false);
    WriteEntity(fout, "trClasses",
        theTranslator->trClasses());
    
    WriteEntity(fout, "trPackageList",
        theTranslator->trPackageList());
    
    WriteEntity(fout, "trPackageListDescription",
        theTranslator->trPackageListDescription());
    
    WriteEntity(fout, "trPackages",
        theTranslator->trPackages());
    
    WriteEntity(fout, "trPackageDocumentation",
        theTranslator->trPackageDocumentation());
    
    WriteEntity(fout, "trDefineValue",
        theTranslator->trDefineValue());
    
    WriteEntity(fout, "trBug",
        theTranslator->trBug());
    
    WriteEntity(fout, "trBugList",
        theTranslator->trBugList());
    
    WriteEntity(fout, "trRTFansicp",
        theTranslator->trRTFansicp());
    
    WriteEntity(fout, "trRTFCharSet",
        theTranslator->trRTFCharSet());
    
    WriteEntity(fout, "trRTFGeneralIndex",
        theTranslator->trRTFGeneralIndex());
    
    
    fout << "\n<!-- Sets of simple entities -->\n";
    
    WriteEntity(fout, "trFileListDescriptionF",
        theTranslator->trFileListDescription(false));
    WriteEntity(fout, "trFileListDescriptionT",
        theTranslator->trFileListDescription(true)); 
    
    fout << "<!-- -->\n";

    Config_setBool(true);
    WriteEntity(fout, "trCompoundMembersDescriptionFC",
        theTranslator->trCompoundMembersDescription(false));
    WriteEntity(fout, "trCompoundMembersDescriptionTC",
        theTranslator->trCompoundMembersDescription(true)); 
    
    Config_setBool(false);
    WriteEntity(fout, "trCompoundMembersDescriptionF",
        theTranslator->trCompoundMembersDescription(false));
    WriteEntity(fout, "trCompoundMembersDescriptionT",
        theTranslator->trCompoundMembersDescription(true)); 
    
    fout << "<!-- -->\n";
    
    Config_setBool(true);
    WriteEntity(fout, "trFileMembersDescriptionFC",
        theTranslator->trFileMembersDescription(false));
    WriteEntity(fout, "trFileMembersDescriptionTC",
        theTranslator->trFileMembersDescription(true)); 
    
    Config_setBool(false);
    WriteEntity(fout, "trFileMembersDescriptionF",
        theTranslator->trFileMembersDescription(false));
    WriteEntity(fout, "trFileMembersDescriptionT",
        theTranslator->trFileMembersDescription(true)); 
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trNamespaceListDescriptionF",
        theTranslator->trNamespaceListDescription(false));
    WriteEntity(fout, "trNamespaceListDescriptionT",
        theTranslator->trNamespaceListDescription(true));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trNamespaceMemberDescriptionF",
        theTranslator->trNamespaceMemberDescription(false));
    WriteEntity(fout, "trNamespaceMemberDescriptionT",
        theTranslator->trNamespaceMemberDescription(true));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trclass",   theTranslator->trClass(false, true ));
    WriteEntity(fout, "trclasses", theTranslator->trClass(false, false));
    WriteEntity(fout, "trClass",   theTranslator->trClass(true,  true ));
    WriteEntity(fout, "trClasses", theTranslator->trClass(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trfile",    theTranslator->trFile(false, true ));
    WriteEntity(fout, "trfiles",   theTranslator->trFile(false, false));
    WriteEntity(fout, "trFile",    theTranslator->trFile(true,  true ));
    WriteEntity(fout, "trFiles",   theTranslator->trFile(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trnamespace",  theTranslator->trNamespace(false, true ));
    WriteEntity(fout, "trnamespaces", theTranslator->trNamespace(false, false));
    WriteEntity(fout, "trNamespace",  theTranslator->trNamespace(true,  true ));
    WriteEntity(fout, "trNamespaces", theTranslator->trNamespace(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trgroup",  theTranslator->trGroup(false, true ));
    WriteEntity(fout, "trgroups", theTranslator->trGroup(false, false));
    WriteEntity(fout, "trGroup",  theTranslator->trGroup(true,  true ));
    WriteEntity(fout, "trGroups", theTranslator->trGroup(true,  false)); 
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trpage",  theTranslator->trPage(false, true ));
    WriteEntity(fout, "trpages", theTranslator->trPage(false, false));
    WriteEntity(fout, "trPage",  theTranslator->trPage(true,  true ));
    WriteEntity(fout, "trPages", theTranslator->trPage(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trmember",  theTranslator->trMember(false, true ));
    WriteEntity(fout, "trmembers", theTranslator->trMember(false, false));
    WriteEntity(fout, "trMember",  theTranslator->trMember(true,  true ));
    WriteEntity(fout, "trMembers", theTranslator->trMember(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trfield",   theTranslator->trField(false, true ));
    WriteEntity(fout, "trfields",  theTranslator->trField(false, false));
    WriteEntity(fout, "trField",   theTranslator->trField(true,  true ));
    WriteEntity(fout, "trFields",  theTranslator->trField(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trglobal",  theTranslator->trGlobal(false, true ));
    WriteEntity(fout, "trglobals", theTranslator->trGlobal(false, false));
    WriteEntity(fout, "trGlobal",  theTranslator->trGlobal(true,  true ));
    WriteEntity(fout, "trGlobals", theTranslator->trGlobal(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trauthor",  theTranslator->trAuthor(false, true ));
    WriteEntity(fout, "trauthors", theTranslator->trAuthor(false, false));
    WriteEntity(fout, "trAuthor",  theTranslator->trAuthor(true,  true ));
    WriteEntity(fout, "trAuthors", theTranslator->trAuthor(true,  false));
    
    fout << "<!-- -->\n";
    
    WriteEntity(fout, "trClassDocGeneratedFromFile",
        theTranslator->trGeneratedFromFiles(ClassDef::Class, true));
    WriteEntity(fout, "trClassDocGeneratedFromFiles",
        theTranslator->trGeneratedFromFiles(ClassDef::Class, false));
    
    fout << "\n";
    
    WriteEntity(fout, "trStructDocGeneratedFromFile",
        theTranslator->trGeneratedFromFiles(ClassDef::Struct, true));
    WriteEntity(fout, "trStructDocGeneratedFromFiles",
        theTranslator->trGeneratedFromFiles(ClassDef::Struct, false)); 
    
    fout << "\n";
    
    WriteEntity(fout, "trUnionDocGeneratedFromFile",
        theTranslator->trGeneratedFromFiles(ClassDef::Union, true));
    WriteEntity(fout, "trUnionDocGeneratedFromFiles",
        theTranslator->trGeneratedFromFiles(ClassDef::Union, false)); 
    
    fout << "\n";
    
    WriteEntity(fout, "trInterfaceDocGeneratedFromFile",
        theTranslator->trGeneratedFromFiles(ClassDef::Interface, true));
    
    WriteEntity(fout, "trInterfaceDocGeneratedFromFiles",
        theTranslator->trGeneratedFromFiles(ClassDef::Interface, false));
    
    fout << "\n";
    
    WriteEntity(fout, "trExceptionDocGeneratedFromFile",
        theTranslator->trGeneratedFromFiles(ClassDef::Exception, true));
    
    WriteEntity(fout, "trExceptionDocGeneratedFromFiles",
        theTranslator->trGeneratedFromFiles(ClassDef::Exception, false));
    
    fout << "<!-- -->\n";
    
    
    fout << "\n------------------------------------------\n\n";
    
    fout << "\n<!-- Template entities (or what should be) -->\n\n";
    
    WriteEntity(fout, "trDefinedAtLineInSourceFile",
        theTranslator->trDefinedAtLineInSourceFile());
    
    WriteEntity(fout, "trDefinedInSourceFile",
        theTranslator->trDefinedInSourceFile());
    
    WriteEntity(fout, "trFileReference",
        theTranslator->trFileReference("$1"));
    
    WriteEntity(fout, "trNamespaceReference",
        theTranslator->trNamespaceReference("$1"));
    
    WriteEntity(fout, "trCollaborationDiagram",
        theTranslator->trCollaborationDiagram("$1"));
    
    WriteEntity(fout, "trInclDepGraph",
        theTranslator->trInclDepGraph("$1"));
    
    WriteEntity(fout, "trPackage",
        theTranslator->trPackage("$1"));
    
    
    fout << "\n<!-- Sets of template entities -->\n\n";
    
    WriteEntity(fout, "trClassReference",
        theTranslator->trCompoundReference("$1", ClassDef::Class, false));
    
    WriteEntity(fout, "trClassTemplateReference",
        theTranslator->trCompoundReference("$1", ClassDef::Class, true)); 
    
    fout << "\n";
    
    WriteEntity(fout, "trStructReference",
        theTranslator->trCompoundReference("$1", ClassDef::Struct, false));
    
    WriteEntity(fout, "trUnionReference",
        theTranslator->trCompoundReference("$1", ClassDef::Union, false));
    
    WriteEntity(fout, "trInterfaceReference",
        theTranslator->trCompoundReference("$1", ClassDef::Interface, false));
    
    WriteEntity(fout, "trExceptionReference",
        theTranslator->trCompoundReference("$1", ClassDef::Exception, false));
    
    fout << "\n<!-- Simple entities with fixed-name generated-entity "
            "references inside\n\n";
    
    WriteEntity(fout, "trGeneratedAutomatically",
        theTranslator->trGeneratedAutomatically("&ProjName;"));
    
    WriteEntity(fout, "trGeneratedAt",
        theTranslator->trGeneratedAt("&GenDate;", "&ProjName;"));
    
    fout << "-->\n\n"
            "<!-- ... but they can be also implemented as template entities)-->\n\n";
    
    WriteEntity(fout, "trGeneratedAutomatically",
        theTranslator->trGeneratedAutomatically("$1"));
    
    WriteEntity(fout, "trGeneratedAt",
        theTranslator->trGeneratedAt("$1", "$2"));
    
    fout << "\n<!-- Simple fragments that should be converted "
            "to template entities -->\n\n";
        
        WriteEntity(fout, "trThisIsTheListOfAllMembers",
        theTranslator->trThisIsTheListOfAllMembers());
    
    WriteEntity(fout, "trIncludingInheritedMembers",
        theTranslator->trIncludingInheritedMembers());
    
    fout << "\n<!-- should be converted to something like... -->\n\n";
    
    WriteEntity(fout, "trThisIsTheListOfAllMembers",
        theTranslator->trThisIsTheListOfAllMembers() + "$1.");
    
    WriteEntity(fout, "trTheListOfAllMembersIncludingInherited",
        theTranslator->trThisIsTheListOfAllMembers() + "$1"
        + theTranslator->trIncludingInheritedMembers());
    
    fout << "\n<! --trWriteList() should be replaced using\n"
        "     &trLSep;, &trLSepAnd2;, and &trLSepAnd; entities\n\n";
    
    WriteEntity(fout, "trWriteList1", theTranslator->trWriteList(1));
    WriteEntity(fout, "trWriteList2", theTranslator->trWriteList(2));
    WriteEntity(fout, "trWriteList3", theTranslator->trWriteList(3));
    
    fout << "-->\n\n";
  
    // Extract the separator definitions.
    //
    std::string sAnd(theTranslator->trWriteList(3));
    std::string s;

    std::string::size_type pos = sAnd.find("@1");
    s = sAnd.substr(2, pos-2);

    sAnd.erase(0, pos+2);
    pos = sAnd.find("@2");
    sAnd.erase(pos);

    std::string sAnd2(theTranslator->trWriteList(2));

    pos = sAnd2.find("@1");
    sAnd2.erase(pos);
    sAnd2.erase(0, 2);

    WriteEntity(fout, "trLSep", s);
    WriteEntity(fout, "trLSepAnd", sAnd);
    WriteEntity(fout, "trLSepAnd2", sAnd2);

    fout << "\n<!-- Should be normal entity templates instead using "
        "trWriteList inside -->\n\n";
    
    // The original.
    //
    fout << "<!--\n";
    WriteEntity(fout, "trInheritsList", 
        theTranslator->trInheritsList(1));
    WriteEntity(fout, "trInheritsList",
        theTranslator->trInheritsList(2));
    WriteEntity(fout, "trInheritsList", 
        theTranslator->trInheritsList(3));
    fout << "-->\n";

    // Two entitities possible -- inheriting from one and many.
    //
    s = theTranslator->trInheritsList(1);
    pos = s.find("@0");
    s.replace(pos, 2, "$1");

    WriteEntity(fout, "trInherits", s);
                      
    s = theTranslator->trInheritsList(2);
    pos = s.find("@0");
    std::string::size_type pos2 = s.find("@1");
    s.replace(pos, pos2-pos+2, "$1");

    WriteEntity(fout, "trInheritsList", s);
    //-----------------------------------------------------------------

    fout << "<!--\n";
    WriteEntity(fout, "trInheritedByList", 
        theTranslator->trInheritedByList(1));
    WriteEntity(fout, "trInheritedByList", 
        theTranslator->trInheritedByList(2));
    WriteEntity(fout, "trInheritedByList", 
        theTranslator->trInheritedByList(3));
    fout << "-->\n";
    
    s = theTranslator->trInheritedByList(1);
    pos = s.find("@0");
    s.replace(pos, 2, "$1");

    WriteEntity(fout, "trInheritedBy", s);
                      
    s = theTranslator->trInheritedByList(2);
    pos = s.find("@0");
    pos2 = s.find("@1");
    s.replace(pos, pos2-pos+2, "$1");

    WriteEntity(fout, "trInheritedByList", s);
    //-----------------------------------------------------------------

    fout << "<!--\n";
    WriteEntity(fout, "trReimplementedFromList", 
        theTranslator->trReimplementedFromList(1));
    WriteEntity(fout, "trReimplementedFromList", 
        theTranslator->trReimplementedFromList(2));
    WriteEntity(fout, "trReimplementedFromList", 
        theTranslator->trReimplementedFromList(3));
    fout << "-->\n";
    
    s = theTranslator->trReimplementedFromList(1);
    pos = s.find("@0");
    s.replace(pos, 2, "$1");

    WriteEntity(fout, "trReimplementedFrom", s);
                      
    s = theTranslator->trReimplementedFromList(2);
    pos = s.find("@0");
    pos2 = s.find("@1");
    s.replace(pos, pos2-pos+2, "$1");

    WriteEntity(fout, "trReimplementedFromList", s);
    //-----------------------------------------------------------------

    fout << "<!--\n";        
    WriteEntity(fout, "trReimplementedInList", 
        theTranslator->trReimplementedInList(1));
    WriteEntity(fout, "trReimplementedInList", 
        theTranslator->trReimplementedInList(2));
    WriteEntity(fout, "trReimplementedInList", 
        theTranslator->trReimplementedInList(3));
    fout << "-->\n";

    s = theTranslator->trReimplementedInList(1);
    pos = s.find("@0");
    s.replace(pos, 2, "$1");

    WriteEntity(fout, "trReimplementedIn", s);
                      
    s = theTranslator->trReimplementedInList(2);
    pos = s.find("@0");
    pos2 = s.find("@1");
    s.replace(pos, pos2-pos+2, "$1");

    WriteEntity(fout, "trReimplementedInList", s);
    //-----------------------------------------------------------------
    
    fout << "\n<!-- (end) -->\n";
    
    // Close the output file.
    //
    fout.close();

    std::cerr << "\n";
}


