#include <iostream>

#include "language.h"
#include "translator.h"
#include "translator_en.h"
#include "translator_nl.h"
#include "translator_cz.h"

Translator * theTranslator = 0;

#define L_EQUAL(a) !stricmp(langName,a)

bool setTranslator(const char *langName)
{
  if (L_EQUAL("english"))
  {
    theTranslator=new TranslatorEnglish;
  }
  else if (L_EQUAL("dutch"))
  {
    theTranslator=new TranslatorDutch;
  }
  else if (L_EQUAL("czech"))
  {
    theTranslator=new TranslatorCzech;
  }
  else // use the default language (i.e. english)
  {
    return false;
  }
  
  QCString msg = theTranslator->updateNeededMessage();
  if (!msg.empty()) 
        std::cerr << msg;
  return true;
}
